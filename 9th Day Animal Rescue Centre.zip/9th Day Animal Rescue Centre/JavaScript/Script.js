// Contact form validation + email compilation (Contact.html only)
const RECIPIENT = "info@the9thday.co.za";
 
const form = document.getElementById("contactForm");
const messageBox = document.getElementById("message");
const counter = document.getElementById("charCount");
 
// Live character counter
messageBox.addEventListener("input", () => {
    counter.textContent = messageBox.value.length + "/500";
});
 
form.addEventListener("submit", (event) => {
    event.preventDefault(); // stay on the page; validation decides what happens next
    checkContactForm();
});
 
function setError(inputId, errorId, text) {
    document.getElementById(errorId).textContent = text;
    document.getElementById(inputId).classList.add("invalid");
}
 
function checkContactForm() {
    // 1. Get the values from the form
    const firstName = document.getElementById("fname").value.trim();
    const lastName = document.getElementById("lname").value.trim();
    const email = document.getElementById("email").value.trim();
    const phone = document.getElementById("phonenumber").value.replace(/[\s-]/g, "");
    const type = document.getElementById("messageType").value;
    const message = messageBox.value.trim();
 
    // 2. Clear old messages
    ["fError", "lError", "emailError", "phoneNumberError", "typeError", "messageError", "result"]
        .forEach(id => (document.getElementById(id).textContent = ""));
    form.querySelectorAll(".invalid").forEach(el => el.classList.remove("invalid"));
 
    // 3. Validate (flag pattern)
    let valid = true;
 
    if (firstName === "") {
        setError("fname", "fError", "Please enter your first name.");
        valid = false;
    } else if (!/^[A-Za-z' -]{2,}$/.test(firstName)) {
        setError("fname", "fError", "Use letters only (at least 2 characters).");
        valid = false;
    }
 
    if (lastName === "") {
        setError("lname", "lError", "Please enter your last name.");
        valid = false;
    } else if (!/^[A-Za-z' -]{2,}$/.test(lastName)) {
        setError("lname", "lError", "Use letters only (at least 2 characters).");
        valid = false;
    }
 
    if (email === "") {
        setError("email", "emailError", "Please enter your email address.");
        valid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        setError("email", "emailError", "Enter a valid email address, e.g. name@example.com.");
        valid = false;
    }
 
    // South African format: 0836557865 or +27836557865
    if (phone === "") {
        setError("phonenumber", "phoneNumberError", "Please enter your phone number.");
        valid = false;
    } else if (!/^(\+27|0)[0-9]{9}$/.test(phone)) {
        setError("phonenumber", "phoneNumberError", "Enter a valid SA number, e.g. 0836557865 or +27836557865.");
        valid = false;
    }
 
    if (type === "") {
        setError("messageType", "typeError", "Please choose a type of message.");
        valid = false;
    }
 
    if (message === "") {
        setError("message", "messageError", "Please type your message.");
        valid = false;
    } else if (message.length < 10) {
        setError("message", "messageError", "Your message must be at least 10 characters long.");
        valid = false;
    }
 
    // 4. Stop if any field is invalid
    if (!valid) {
        const firstBad = form.querySelector(".invalid");
        if (firstBad) firstBad.focus();
        return false;
    }
 
    // 5. Compile the email and hand it to the visitor's email app
    const subject = type + " enquiry from " + firstName + " " + lastName;
    const body =
        "Name: " + firstName + " " + lastName + "\n" +
        "Email: " + email + "\n" +
        "Phone: " + phone + "\n" +
        "Message type: " + type + "\n\n" +
        message;
    const mailto = "mailto:" + RECIPIENT +
        "?subject=" + encodeURIComponent(subject) +
        "&body=" + encodeURIComponent(body);
 
    // Build the result with DOM methods (no innerHTML with user data)
    const result = document.getElementById("result");
    result.textContent = "Thank you, " + firstName + ". Your email is ready to send. If your email app did not open, ";
    const link = document.createElement("a");
    link.href = mailto;
    link.textContent = "click here to send it";
    result.appendChild(link);
    result.appendChild(document.createTextNode("."));
 
    window.location.href = mailto;
    return false;
}
