
const form = document.getElementById("enquiryForm");
const typeSelect = document.getElementById("enquiryType");
const groups = { adopt: "adoptGroup", sponsor: "sponsorGroup", volunteer: "volunteerGroup" };



const FALLBACK_INFO = {
  "adoption": {
    "fee": "R1 200",
    "includes": "vaccinations, deworming, sterilisation and microchipping",
    "animals": {
      "Rudie": {
        "status": "Available",
        "note": "Rudie is 10 years old and has been with us for 6 months."
      },
      "Bobby": {
        "status": "Available",
        "note": "Bobby is 5 years old and best suited to an active family."
      },
      "Wimpie": {
        "status": "Available",
        "note": "Wimpie is 5 months old and loves cuddles."
      }
    }
  },
  "sponsorship": {
    "tiers": {
      "Bronze": {
        "amount": "R150 per month",
        "covers": "Covers food for one dog."
      },
      "Silver": {
        "amount": "R300 per month",
        "covers": "Covers food and basic vet care for one dog."
      },
      "Gold": {
        "amount": "R500 per month",
        "covers": "Covers food, vet care and shelter costs for one dog."
      }
    }
  },
  "volunteering": {
    "hours": {
      "Monday": "10:00 AM-4:30 PM",
      "Tuesday": "10:00 AM-4:30 PM",
      "Wednesday": "10:00 AM-4:30 PM",
      "Thursday": "10:00 AM-4:30 PM",
      "Friday": "10:00 AM-4:30 PM",
      "Saturday": "10:00 AM-2:00 PM",
      "Sunday": "10:00 AM-12:00 PM"
    }
  }
};

let info = null;
const infoLoaded = fetch("Documents/Enquiry info.json")
    .then((r) => { if (!r.ok) throw new Error("Not found"); return r.json(); })
    .then((data) => { info = data; })
    .catch(() => { info = FALLBACK_INFO; });

function showGroup() {
    Object.keys(groups).forEach((key) => {
        document.getElementById(groups[key]).hidden = typeSelect.value !== key;
    });
}
typeSelect.addEventListener("change", showGroup);


const wanted = new URLSearchParams(window.location.search).get("animal");
if (wanted && Array.from(document.getElementById("animal").options).some((o) => o.value === wanted)) {
    typeSelect.value = "adopt";
    showGroup();
    document.getElementById("animal").value = wanted;
}

function setError(inputId, errorId, text) {
    document.getElementById(errorId).textContent = text;
    document.getElementById(inputId).classList.add("invalid");
}

function validate() {
    const v = {
        name: document.getElementById("fname").value.trim(),
        email: document.getElementById("email").value.trim(),
        phone: document.getElementById("phonenumber").value.replace(/[\s-]/g, ""),
        type: typeSelect.value,
        animal: document.getElementById("animal").value,
        tier: document.getElementById("tier").value,
        day: document.getElementById("day").value
    };

    ["fError", "emailError", "phoneNumberError", "typeError", "animalError", "tierError", "dayError"]
        .forEach((id) => (document.getElementById(id).textContent = ""));
    form.querySelectorAll(".invalid").forEach((el) => el.classList.remove("invalid"));
    document.getElementById("result").replaceChildren();

    let valid = true;
    if (v.name === "") { setError("fname", "fError", "Please enter your name."); valid = false; }
    else if (!/^[A-Za-z' -]{2,}$/.test(v.name)) { setError("fname", "fError", "Use letters only (at least 2 characters)."); valid = false; }

    if (v.email === "") { setError("email", "emailError", "Please enter your email address."); valid = false; }
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email)) { setError("email", "emailError", "Enter a valid email address, e.g. name@example.com."); valid = false; }

    if (v.phone === "") { setError("phonenumber", "phoneNumberError", "Please enter your phone number."); valid = false; }
    else if (!/^(\+27|0)[0-9]{9}$/.test(v.phone)) { setError("phonenumber", "phoneNumberError", "Enter a valid SA number, e.g. 0836557865 or +27836557865."); valid = false; }

    if (v.type === "") { setError("enquiryType", "typeError", "Please choose what you would like to do."); valid = false; }
    if (v.type === "adopt" && v.animal === "") { setError("animal", "animalError", "Please choose a dog."); valid = false; }
    if (v.type === "sponsor" && v.tier === "") { setError("tier", "tierError", "Please choose a sponsorship level."); valid = false; }
    if (v.type === "volunteer" && v.day === "") { setError("day", "dayError", "Please choose a preferred day."); valid = false; }

    if (!valid) {
        const firstBad = form.querySelector(".invalid");
        if (firstBad) firstBad.focus();
        return null;
    }
    return v;
}

function showResponse(v) {
    const out = document.getElementById("result");
    out.replaceChildren();
    const add = (tag, text) => {
        const el = document.createElement(tag);
        el.textContent = text;
        out.appendChild(el);
    };

    if (!info) {
        add("h3", "Thank you, " + v.name + "!");
        add("p", "We could not load our latest details right now. Please phone us on +27 60 406 5263 and we will help you directly.");
        return;
    }

    add("h3", "Thank you, " + v.name + "!");
    if (v.type === "adopt") {
        const dog = info.adoption.animals[v.animal];
        add("p", v.animal + " is currently: " + dog.status + ". " + dog.note);
        add("p", "Adoption fee: " + info.adoption.fee + ", which includes " + info.adoption.includes + ".");
        add("p", "Come and meet " + v.animal + " during our opening hours, or phone +27 60 406 5263 to book a time.");
    } else if (v.type === "sponsor") {
        const tier = info.sponsorship.tiers[v.tier];
        add("p", v.tier + " sponsorship: " + tier.amount + ". " + tier.covers);
        add("p", "Contact us on info@the9thday.co.za to set up your sponsorship.");
    } else {
        add("p", "We would love your help! On " + v.day + " we are open " + info.volunteering.hours[v.day] + ".");
        add("p", "Pop in during those hours and ask for the volunteer coordinator, or phone +27 60 406 5263.");
    }
    out.tabIndex = -1;
    out.focus();
}

form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const values = validate();
    if (!values) return;
    await infoLoaded;
    showResponse(values);
});
