(function () {
    const thumbs = Array.from(document.querySelectorAll(".gallery img"));
    if (thumbs.length === 0) return;
 
    let index = 0;
    let opener = null;
 
    const box = document.createElement("div");
    box.className = "lightbox";
    box.hidden = true;
    box.setAttribute("role", "dialog");
    box.setAttribute("aria-modal", "true");
    box.setAttribute("aria-label", "Image viewer");
    box.innerHTML =
        '<button class="lb-close" aria-label="Close image">&times;</button>' +
        '<button class="lb-prev" aria-label="Previous image">&#8249;</button>' +
        '<img alt="">' +
        '<p class="lb-cap"></p>' +
        '<button class="lb-next" aria-label="Next image">&#8250;</button>';
    document.body.appendChild(box);
 
    const bigImg = box.querySelector("img");
    const caption = box.querySelector(".lb-cap");
 
    function show(i) {
        index = (i + thumbs.length) % thumbs.length;
        bigImg.src = thumbs[index].src;
        bigImg.alt = thumbs[index].alt;
        caption.textContent = thumbs[index].alt;
    }
    function open(i) {
        opener = thumbs[i];
        show(i);
        box.hidden = false;
        box.querySelector(".lb-close").focus();
    }
    function close() {
        box.hidden = true;
        if (opener) opener.focus();
    }
 
    thumbs.forEach((img, i) => {
        img.tabIndex = 0;
        img.setAttribute("role", "button");
        img.addEventListener("click", () => open(i));
        img.addEventListener("keydown", (e) => {
            if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(i); }
        });
    });
 
    box.querySelector(".lb-close").addEventListener("click", close);
    box.querySelector(".lb-prev").addEventListener("click", () => show(index - 1));
    box.querySelector(".lb-next").addEventListener("click", () => show(index + 1));
    box.addEventListener("click", (e) => { if (e.target === box) close(); });
    document.addEventListener("keydown", (e) => {
        if (box.hidden) return;
        if (e.key === "Escape") close();
        if (e.key === "ArrowLeft") show(index - 1);
        if (e.key === "ArrowRight") show(index + 1);
    });
})();
