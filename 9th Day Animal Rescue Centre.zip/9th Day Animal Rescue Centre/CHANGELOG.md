# Improvements from part 2


## [Part 3] - 2026-11-02

### Added
- **Contact form** (`Contact.html`): first name, last name, email, phone, message type, message. Validated in "JavaScript/Script.js"; once valid it is compiled into a `mailto:` email to `info@the9thday.co.za`.
- **Google Map** embed and "Get directions" link on `Contact.html`.
- **Enquiry page** (`Enquiry.html`, `JavaScript/enquiry.js`): adopt a dog, sponsor an animal or volunteer. After validation it shows the adoption fee and dog availability, the sponsorship cost, or the opening hours for the chosen day. Details are loaded with AJAX (`fetch`) from `Documents/Enquiry info.json".
- "Please Adopt Me!" buttons now open the enquiry form with that dog pre-selected.
- **Gallery lightbox** (`JavaScript/lightbox.js`) on Animals and Fundraising: click or press Enter on an image; arrow keys and Esc work.
- All the css lightboxes are all styled within the css stylesheet
- **SEO**: unique title and meta description per page, keywords, Open Graph tags, one `<h1>` per page with a logical heading order, descriptive `alt` text, `robots.txt`, `sitemap.xml`.
- **Speed**: `loading="lazy"` on below-the-fold images, `preload="none"` on videos.
- **Security**: `_headers` file (Netlify), errors written with `textContent` instead of `innerHTML`.

# Changed (Part 2 feedback)
- Removed the duplicated inline `<style>` block from every page; all styling now comes from the stylesheets.
- Moved the stylesheet link into `<head>` and fixed the viewport meta tag.
- Replaced inline `style=""` attributes with classes.
- Fixed invalid HTML (unclosed `<p>`/`<li>`, stray `</br>`, unclosed `<div>`) on About and Home.
- Fixed video paths (leading space and lowercase `images/`).
- Renamed `Home.html` to `index.html` so Netlify/GitHub Pages load the home page at the site address.
- Added a link to Enquiries in the navigation and highlighted the current page.
- Corrected spelling mistakes ("Rehabilition", "recue", "throuhout", "Booby").

# References
- MDN Web Docs: Regular expressions, `fetch()`, `<form>`, `<iframe>`, `mailto:` links.
- Google Maps: embedding a map and directions URLs.
- Google Search Central: robots.txt and sitemap guidance.
- Class tutorial: HTML/JavaScript form validation (flag pattern).
